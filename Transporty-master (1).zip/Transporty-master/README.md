<h1>Transpoty</h1>
Online bus schedule and booking system is a Web based application. This allows passengers to book
a seat on the bus to their destination and add their bus to the bus driver reservation system.
The online transport booking system will be developed to make sure that the user can make
necessary booking processes of the transport online with facilities provided by this system. It
also helps customers to have easier access for reservation of their tickets. The use of bus
traveling is a large growing business in Nigeria and other countries;
Our main objective is to create such an advanced system in Sri Lanka and contribute to the
development of the country
Bus transport is a popular mode of transport in Sri Lanka. But passengers may face some difficulties
while using this medium (especially on long journeys).
Some of these are,
<ul>
<li>Lack of understanding of bus travel times.</li>
<li>Having to travel without a seat to the destination.</li>
<li>Lack of understanding of travel expenses.</li>
</ul>

Therefore, we consider this inconvenience and present this application as a solution to avoid those
difficulties. Users can use this app directly through the web browser without having to install it. We
also have a 24 hour service and a customer service that works 24 hours a day to solve problems for
users.
There are 3 packages for the passenger; namely,
<ol>
<li>Normal</li>
<li>Semi - luxury</li>
<li>Luxury</li>
</ol>

The passenger can select their route, select the relevant package and reserve a seat after paying.
Any user can visit the website and search the schedule and it is mandatory to open an account on
our website for bookings.
Here are the services that are available to any user without opening an account.
<ul>
<li>Buses available on the route.</li>
<li>Cost per seat (separately for each package)</li>
<li>Refer to the bus schedule etc.</li>
</ul>

If users use our website as a driver, it is mandatory to open an account and confirm the information
we request.
The reservation system consists of several steps.
<ol>
<li>Select the relevant route and perform the search.</li>
<li>Select the required bus if it is available and log in to the account.</li>
<li>Select the required number of seats and make payments using a convenient medium.</li>
</ol>

After completing this step we will send the ticket number to the user's email account and phone
number.
