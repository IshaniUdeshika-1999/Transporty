function myFunction() {
  var person = prompt("Please enter your problem", " ");
  
}