function form1()
{
	document.getElementById("a").style.bottom="1000px";
	document.getElementById("b").style.top="-1000px";
	
	
}


function form1()
{
  document.getElementById("a").style.display = "block";
  document.getElementById("b").style.display = "none";
  document.getElementById("c").style.display = "none";
  document.getElementById("d").style.display = "none";

}

function form2()
{
  document.getElementById("b").style.display = "block";
  document.getElementById("a").style.display = "none";
  document.getElementById("c").style.display = "none";
  document.getElementById("d").style.display = "none";

}

function form3()
{
  document.getElementById("c").style.display = "block";
  document.getElementById("b").style.display = "none";
  document.getElementById("a").style.display = "none";
  document.getElementById("d").style.display = "none";

}

function form4()
{
  document.getElementById("d").style.display = "block";
  document.getElementById("b").style.display = "none";
  document.getElementById("c").style.display = "none";
  document.getElementById("a").style.display = "none";
}


